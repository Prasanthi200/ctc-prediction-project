# 💼 Data Science Project – Expected CTC Prediction

## Project Overview
Predict Expected CTC (salary) of a candidate from their profile data.

## Project Structure
project1/
  data/expected_ctc.csv
  src/
    train_model.py
    predict_example.py
  artifacts/
    model.pkl
    metrics.json
    sample_predictions.csv
  requirements.txt
  README.md

## Installation (Windows)
1. Open VS Code → Terminal (Ctrl+`)
2. Create virtual env:
   python -m venv .venv
   .venv\Scripts\activate
3. Install packages:
   pip install -r requirements.txt

## Train the model
python src/train_model.py

## Predict (example)
python src/predict_example.py

## Results (from this run)
MAE: 27,884.05
RMSE: 41,914.99
R²: 0.9986

## Next steps
- Tune models (RandomForest, XGBoost)
- Exclude Current_CTC to reduce leakage
- Deploy with Flask/Streamlit for demo

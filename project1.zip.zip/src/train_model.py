\
import os, json, joblib, numpy as np, pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# Paths
BASE_DIR = os.path.dirname(os.path.dirname(__file__))
DATA_PATH = os.path.join(BASE_DIR, "data", "expected_ctc.csv")
OUT_DIR = os.path.join(BASE_DIR, "artifacts")
os.makedirs(OUT_DIR, exist_ok=True)

# Load
df = pd.read_csv(DATA_PATH)
# Speed-up for demo: take a random subset if dataset is large
if len(df) > 8000:
    df = df.sample(8000, random_state=42).reset_index(drop=True)

# Keep only a compact set of useful columns to speed up demo training
keep_cols = [col for col in [
    "Total_Experience",
    "Total_Experience_in_field_applied",
    "Department",
    "Role",
    "Industry",
    "Designation",
    "Education",
    "Graduation_Specialization",
    "University_Grad",
    "Passing_Year_Of_Graduation",
    "PG_Specialization",
    "Passing_Year_Of_PG",
    "Curent_Location",
    "Preferred_location",
    "Current_CTC",
    "Inhand_Offer",
    "Last_Appraisal_Rating",
    "No_Of_Companies_worked",
    "Number_of_Publications",
    "Certifications",
    "International_degree_any",
    "Expected_CTC"
] if col in df.columns]

df = df[keep_cols].copy()




# Target and drops
TARGET = "Expected_CTC"

# Keep only a compact set of useful columns to speed up demo training
keep_cols = [col for col in [
    "Total_Experience",
    "Total_Experience_in_field_applied",
    "Department",
    "Role",
    "Industry",
    "Designation",
    "Education",
    "Graduation_Specialization",
    "University_Grad",
    "Passing_Year_Of_Graduation",
    "PG_Specialization",
    "Passing_Year_Of_PG",
    "Curent_Location",
    "Preferred_location",
    "Current_CTC",
    "Inhand_Offer",
    "Last_Appraisal_Rating",
    "No_Of_Companies_worked",
    "Number_of_Publications",
    "Certifications",
    "International_degree_any",
    "Expected_CTC"
] if col in df.columns]

df = df[keep_cols].copy()

drop_cols = ["IDX", "Applicant_ID"]  # ID-like columns that don't carry real signal
df = df.drop(columns=[c for c in drop_cols if c in df.columns])
# Extra downsample for speed
if len(df) > 5000:
    df = df.sample(5000, random_state=42).reset_index(drop=True)

# Separate features/target
y = df[TARGET].astype(float)
X = df.drop(columns=[TARGET])

# Identify column types
numeric_cols = []
categorical_cols = []
for c in X.columns:
    if pd.api.types.is_numeric_dtype(X[c]):
        numeric_cols.append(c)
    else:
        categorical_cols.append(c)

# Simple preprocessors
numeric_transformer = Pipeline(steps=[
    ("imputer", SimpleImputer(strategy="median"))
])

categorical_transformer = Pipeline(steps=[
    ("imputer", SimpleImputer(strategy="most_frequent")),
   ("onehot",OneHotEncoder(handle_unknown="ignore", sparse_output=False))
])

preprocess = ColumnTransformer(
    transformers=[
        ("num", numeric_transformer, numeric_cols),
        ("cat", categorical_transformer, categorical_cols),
    ]
)

# Model
model = RandomForestRegressor(
    n_estimators=120,
    max_depth=12,
    random_state=42,
    n_jobs=-1
)

# Full pipeline
pipe = Pipeline(steps=[("preprocess", preprocess), ("model", model)])

# Split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Fit
pipe.fit(X_train, y_train)

# Predict & metrics
preds = pipe.predict(X_test)
mae = mean_absolute_error(y_test, preds)
mse = mean_squared_error(y_test, preds)
rmse = mse ** 0.5
r2 = r2_score(y_test, preds)

metrics = {"MAE": mae, "RMSE": rmse, "R2": r2}
with open(os.path.join(OUT_DIR, "metrics.json"), "w") as f:
    json.dump(metrics, f, indent=2)

# Feature importance (approximate): map model importances back to one-hot columns
# Get transformed feature names
def get_feature_names(preprocessor, input_features):
    output_features = []
    for name, trans, cols in preprocessor.transformers_:
        if name == "remainder" and trans == "drop":
            continue
        if hasattr(trans, "get_feature_names_out"):
            # OneHotEncoder case
            sub_features = trans.get_feature_names_out(cols)
            output_features.extend(list(sub_features))
        elif isinstance(trans, Pipeline):
            last_step = trans.steps[-1][1]
            if hasattr(last_step, "get_feature_names_out"):
                sub_features = last_step.get_feature_names_out(cols)
                output_features.extend(list(sub_features))
            else:
                output_features.extend(cols)
        else:
            # SimpleImputer or passthrough
            output_features.extend(cols)
    return output_features

# Extract feature importances from the RF
rf = pipe.named_steps["model"]
feature_names = get_feature_names(pipe.named_steps["preprocess"], X_train.columns)
importances = getattr(rf, "feature_importances_", None)

fi_path = os.path.join(OUT_DIR, "feature_importance.csv")
if importances is not None and len(feature_names) == len(importances):
    fi = pd.DataFrame({"feature": feature_names, "importance": importances})
    fi = fi.sort_values("importance", ascending=False)
    fi.to_csv(fi_path, index=False)
else:
    pd.DataFrame({"note": ["Feature importances unavailable"]}).to_csv(fi_path, index=False)

# Save a sample predictions file
sample_df = pd.DataFrame({
    "Expected_CTC_actual": y_test.reset_index(drop=True),
    "Expected_CTC_pred": pd.Series(preds)
})
sample_df.head(1000).to_csv(os.path.join(OUT_DIR, "sample_predictions.csv"), index=False)

# Persist model
joblib.dump(pipe, os.path.join(OUT_DIR, "model.pkl"))

print("Training complete.")
print("Metrics:", metrics)
print("Artifacts saved to:", OUT_DIR)

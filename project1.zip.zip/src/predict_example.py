\
import os, joblib, pandas as pd

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "artifacts", "model.pkl")

pipe = joblib.load(MODEL_PATH)
csv_path = os.path.join(BASE_DIR, "data", "expected_ctc.csv")
df = pd.read_csv(csv_path).drop(columns=["Expected_CTC"])
# --- START custom example block (replace df.head(5) part) ---
# Use the first row as a template, then change values you want
template = df.head(1).copy()   # one row without Expected_CTC
# Example: set custom values in the first row (row index 0)
template.loc[0, "Total_Experience"] = 5.0
template.loc[0, "Total_Experience_in_field_applied"] = 3.0
template.loc[0, "Department"] = "IT"
template.loc[0, "Role"] = "Developer"
template.loc[0, "Industry"] = "Software"
template.loc[0, "Designation"] = "Software Engineer"
template.loc[0, "Education"] = "Bachelors"
template.loc[0, "Graduation_Specialization"] = "Computer Science"
template.loc[0, "University_Grad"] = "XYZ University"
template.loc[0, "Passing_Year_Of_Graduation"] = 2018
template.loc[0, "Curent_Location"] = "Bengaluru"
template.loc[0, "Preferred_location"] = "Bengaluru"
template.loc[0, "Current_CTC"] = 600000
template.loc[0, "Inhand_Offer"] = 0
template.loc[0, "Last_Appraisal_Rating"] = 4
template.loc[0, "No_Of_Companies_worked"] = 2
template.loc[0, "Number_of_Publications"] = 0
template.loc[0, "Certifications"] = 0
template.loc[0, "International_degree_any"] = 0

example = template  # now example has 1 custom row
# --- END custom example block ---
preds = pipe.predict(example)
print("Predictions for 5 sample rows:")
print(preds)
# Save prediction result to artifacts folder
output_path = os.path.join(BASE_DIR, "artifacts", "custom_prediction.csv")
pd.DataFrame({"Predicted_CTC": preds}).to_csv(output_path, index=False)
print(f"Saved predictions to {output_path}")
